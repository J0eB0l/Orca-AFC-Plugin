"""AFC's lanes as the AMS trays OrcaSlicer's device model reads.

OrcaSlicer keeps a printer's filaments in Bambu's AMS shape: units of up to
four trays (ids 0-6, a tray id being unit * 4 + slot) and one-tray AMS HT units
(ids 128-135, a tray id being the unit id); the AFC build reads more of both
(WIDE). Two layouts fit AFC's T numbers to it:

- By T number, as OrcaSlicer's own Moonraker agent lays out AFC's lane data:
  T(n) is tray n, in unit n // 4, slot n % 4. Filament sync then puts tray n in
  project slot n + 1, and the print dialog's tray for a filament is the T
  number it prints with.
- By AFC unit, when OrcaSlicer syncs each tray to the slot of the T number the
  tray reports (the AFC build says so in its pushall): each unit's lanes in
  its own AMS, four to one, and a unit with one lane, or a toolchanger's tool,
  an AMS HT. A unit with a dryer is an AMS 2 Pro (one lane: an AMS HT), which
  shows its humidity and takes OrcaSlicer's drying popup; one without is an AMS
  that shows no humidity. A Bambu AMS Lite of four lanes is drawn as one.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from . import runout
from .protocol import Dryer, Lane, Snapshot, Switch, material_key, tool_number

# OrcaSlicer reads the tray presence bits with stol(), which a bit past 30
# overflows on Windows (32-bit long), and the bit test itself shifts an int.
MAX_TRAY = 30
NO_TRAY = 0xFF
# An AMS HT's bits sit at 4 + n (unit) and 16 + n (tray) for unit id 128 + n,
# so beside more than four four-tray units the HT ids start past their trays' bits.
HT_ID, MAX_HT = 128, 8
MAX_BOXES = 7
# AMS types in a unit's "info": an AMS, an AMS Lite, an AMS 2 Pro, an AMS HT.
AMS, AMS_LITE, AMS_2_PRO, AMS_HT = 1, 2, 3, 4
LITE = "lite"  # a Bambu unit's ams_model for an AMS Lite
DRYING, HEATING = 2, 1  # the dry status and sub status OrcaSlicer reads in "info"
DRY_DISCONNECTED = 100  # the AFC build of OrcaSlicer's "cannot dry" reason for a unit not connected
TOOLCHANGER = "Toolchanger"  # AFC's unit type for a toolchanger's tools


@dataclass(frozen=True)
class Limits:
    """How many T numbers and units OrcaSlicer reads, and the bits an AMS HT's
    unit and tray start at in its unit and tray masks."""
    max_tray: int = MAX_TRAY
    max_boxes: int = MAX_BOXES
    max_ht: int = MAX_HT
    ht_ams_bit: int = 4
    ht_tray_bit: int = 16


BAMBU = Limits()
# The AFC build of OrcaSlicer reads the masks as 64 bits and takes the AMS HT
# bits from the "ams" object (it says so with "tray_bits64" in its pushall):
# twelve four-tray units on tray bits 0-47, sixteen AMS HT units on unit bits
# 32-47 and tray bits 48-63, and a T number for every filament slot.
WIDE = Limits(max_tray=63, max_boxes=12, max_ht=16, ht_ams_bit=32, ht_tray_bit=48)


@dataclass
class Box:
    """A unit OrcaSlicer shows: up to four trays, or one for an AMS HT."""
    ams_id: int
    tools: list = field(default_factory=list)  # the T number in each slot
    unit: str = ""                             # the AFC unit it shows ("" by T number)

    @property
    def single(self) -> bool:
        return self.ams_id >= HT_ID


class Layout:
    """Which unit and slot OrcaSlicer shows each T number in, and back."""

    def __init__(self, boxes: list, by_unit: bool = False, aliases: dict | None = None,
                 limits: Limits = BAMBU):
        self.boxes, self.by_unit, self.limits = boxes, by_unit, limits
        self._at = {tool: (box, slot) for box in boxes for slot, tool in enumerate(box.tools)}
        # A T number a lane holds beside the one its tray shows lives in that tray.
        for alias, tool in (aliases or {}).items():
            if tool in self._at:
                self._at[alias] = self._at[tool]

    def box(self, ams_id) -> Box | None:
        return next((box for box in self.boxes if box.ams_id == ams_id), None)

    def tool(self, ams_id, slot_id) -> int:
        """The T number in a unit's slot, -1 for none."""
        if not _is_int(ams_id) or not _is_int(slot_id) or not 0 <= slot_id < 4 or ams_id < 0:
            return -1
        if not self.by_unit:
            tray = ams_id * 4 + slot_id
            return tray if tray <= self.limits.max_tray else -1
        box = self.box(ams_id)
        return box.tools[slot_id] if box is not None and slot_id < len(box.tools) else -1

    def tool_of_tray(self, tray) -> int:
        """The T number of a tray id, -1 for none."""
        if not _is_int(tray) or tray < 0:
            return -1
        return self.tool(tray, 0) if HT_ID <= tray < HT_ID + self.limits.max_ht else self.tool(tray // 4, tray % 4)

    def tray(self, tool: int) -> int:
        """The tray id OrcaSlicer knows T(tool) by, NO_TRAY for none."""
        at = self._at.get(tool)
        if at is None:
            return NO_TRAY
        box, slot = at
        return box.ams_id if box.single else box.ams_id * 4 + slot

    def place(self, lane: Lane) -> tuple:
        """The unit id and slot the Device tab shows a lane in, (-1, -1) for none."""
        for m in lane.maps:
            at = self._at.get(tool_number(m))
            if at is not None:
                return at[0].ams_id, at[1]
        return -1, -1


def _is_int(v) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def lanes_by_tray(snapshot: Snapshot) -> dict:
    """T number -> the lane AFC maps to it, for T0 to T63 (layout() keeps the
    ones OrcaSlicer reads)."""
    out = {}
    for lane in snapshot.lanes:
        for m in lane.maps:
            tool = tool_number(m)
            if 0 <= tool <= WIDE.max_tray and tool not in out:
                out[tool] = lane
    return out


def layout(snapshot: Snapshot | None, by_unit: bool = False, wide: bool = False) -> Layout:
    """The layout of AFC's T numbers: by AFC unit when asked and it fits
    OrcaSlicer's units, else by T number. `wide`: the AFC build reads the
    WIDE limits."""
    limits = WIDE if by_unit and wide else BAMBU
    trays = lanes_by_tray(snapshot) if snapshot is not None else {}
    trays = {tool: lane for tool, lane in trays.items() if tool <= limits.max_tray}
    if by_unit and trays:
        fit = _unit_boxes(snapshot, trays, limits)
        if fit is not None:
            return Layout(fit[0], True, fit[1], limits)
    last = max(trays) if trays else -1
    return Layout([Box(unit, [unit * 4 + slot for slot in range(min(3, last - unit * 4) + 1)])
                   for unit in range(last // 4 + 1)], limits=limits)


def _unit_boxes(snapshot: Snapshot, trays: dict, limits: Limits = BAMBU):
    """Each AFC unit's lanes, in lane order, as OrcaSlicer units, and the T
    numbers that are aliases of a shown one; None when they do not fit.

    A lane is one tray, under its first T number in AFC's map order. The
    others it holds (a print maps its filaments onto lanes that way, T0 onto
    lane14 beside its own T14) are aliases: as trays they would split the unit
    in two and could leave too many units to lay out by unit."""
    own = {}  # lane name -> the T number its tray shows
    for tool in sorted(trays):
        lane = trays[tool]
        if lane.name not in own:
            own[lane.name] = next(t for t in map(tool_number, lane.maps) if trays.get(t) is lane)
    groups = {}  # AFC unit -> its lanes' T numbers, its units first and in lane order
    for unit in snapshot.units:
        for name in unit.lanes:
            if name in own and trays[own[name]].unit == unit.name:
                groups.setdefault(unit.name, []).append(own[name])
    for tool in sorted(own.values()):
        if not any(tool in tools for tools in groups.values()):
            groups.setdefault(trays[tool].unit, []).append(tool)
    boxes, singles = [], []
    for name, tools in groups.items():
        unit = snapshot.find_unit(name)
        if len(tools) == 1 or (unit is not None and unit.type == TOOLCHANGER):
            singles += [(tool, name) for tool in tools]
        else:
            boxes += [(tools[i:i + 4], name) for i in range(0, len(tools), 4)]
    # The AMS HT ids start past the four-tray units' tray bits.
    first_ht = max(0, 4 * len(boxes) - limits.ht_tray_bit) if singles else 0
    if len(boxes) > limits.max_boxes or first_ht + len(singles) > limits.max_ht:
        return None
    aliases = {tool: own[lane.name] for tool, lane in trays.items() if own[lane.name] != tool}
    return ([Box(i, tools, name) for i, (tools, name) in enumerate(boxes)] +
            [Box(HT_ID + first_ht + i, [tool], name) for i, (tool, name) in enumerate(sorted(singles))]), aliases


def _color(hex_color: str) -> str:
    """"#RRGGBB" -> "RRGGBBFF", OrcaSlicer's tray color; "" for no color."""
    return hex_color[1:].upper() + "FF" if hex_color else ""


def remaining(lane: Lane) -> int:
    """Share of the spool left, 0-100, or -1 when AFC has no weight for it."""
    if not lane.has_filament or lane.weight <= 0:
        return -1
    initial = lane.initial_weight if lane.initial_weight > 0 else 1000.0
    return max(0, min(100, int(round(lane.weight / initial * 100))))


def tray_json(slot: int, lane: Lane | None, filament_id: str, extra: dict | None = None, tool: int = -1,
              switch=()) -> dict:
    """A tray of the "ams" object, T(tool). `extra` adds the spool and preset
    fields the agent works out for a loaded tray (see spool_json()), `switch`
    is the lane's switch_toolheads()."""
    tray = {"id": str(slot), "tag_uid": "0000000000000000"}
    if tool >= 0:
        # The AFC build of OrcaSlicer syncs the tray to that T number's slot.
        tray["tool"] = tool
    if switch:
        # ... and lets Load pick which of the two toolheads the lane's filament switch feeds it to.
        tray["switch_toolheads"] = list(switch)
    if lane is None or not lane.has_filament:
        tray.update(tray_info_idx="", tray_type="", tray_color="00000000", tray_slot_placeholder="1")
        return tray
    tray.update(tray_info_idx=filament_id, tray_type=lane.material or "", tray_color=_color(lane.color) or "00000000")
    if len(lane.multi_colors) > 1:
        tray["cols"] = [_color(c) for c in lane.multi_colors if c]
    if lane.nozzle_temp > 0:
        tray["nozzle_temp_max"] = tray["nozzle_temp_min"] = str(lane.nozzle_temp)
    if lane.bed_temp > 0:
        tray["bed_temp"] = str(lane.bed_temp)
    if lane.diameter > 0:
        tray["tray_diameter"] = "%.2f" % lane.diameter
    if lane.filament_name:
        tray["tray_sub_brands"] = lane.filament_name
    left = remaining(lane)
    if left >= 0:
        tray["remain"] = left
        # The AFC build of OrcaSlicer draws the share left on any spool that has it, and checks a print fits.
        tray["remain_g"] = int(round(lane.weight))
    # 0 for none: OrcaSlicer keeps a tray's last K when the field is missing.
    tray["k"] = max(lane.flow_k, 0.0)
    if lane.extruder_index >= 0:
        # The AFC build of OrcaSlicer keeps it per filament at sync, for "Purge in prime tower".
        tray["toolhead"] = lane.extruder_index
    if lane.tool_loaded:
        # The AFC build of OrcaSlicer shows it loaded, in a docked tool too.
        tray["in_tool"] = True
    if lane.runout_lane:
        # ... and marks the tray with the lane it runs out onto.
        tray["runout"] = lane.runout_lane
    tray.update(extra or {})
    return tray


def spool_json(lane: Lane, names: list, base: str) -> dict:
    """What OrcaSlicer's filament sync makes the spool's own preset from: the
    names it may have (presets.spool_preset_names()), the preset to copy when
    there is none (`base`), and the spool's values to put in it."""
    return {"names": list(names), "base": base, "vendor": lane.vendor, "nozzle_temp": lane.nozzle_temp,
            "bed_temp": lane.bed_temp, "density": lane.density, "diameter": lane.diameter,
            "pressure_advance": lane.flow_k}


def current_tray(snapshot: Snapshot) -> int:
    """The T number of the lane AFC has in the active toolhead, -1 for none."""
    lane = snapshot.find_lane(snapshot.current_lane) if snapshot.current_lane else None
    tools = [tool_number(m) for m in lane.maps] if lane is not None else []
    return next((t for t in tools if 0 <= t <= WIDE.max_tray), -1)


def humidity_level(percent: float) -> int:
    """Bambu's humidity level for a percentage, 5 the driest."""
    return 5 if percent < 20 else 4 if percent < 40 else 3 if percent < 60 else 2 if percent < 80 else 1


def dryer_json(dryer: Dryer, filament: str = "") -> dict:
    """A dryer unit's humidity, temperature and drying, as an AMS 2 Pro or AMS
    HT reports them; `filament` is what the drying popup named."""
    out = {"dry_time": -(-dryer.remaining_s // 60) if dryer.drying else 0,
           # Why it cannot dry, sent every time so the AFC build of OrcaSlicer clears it once plugged in.
           "dry_sf_reason": [] if dryer.online else [DRY_DISCONNECTED]}
    if dryer.humidity >= 0:
        out["humidity_raw"] = str(int(round(dryer.humidity)))
        out["humidity"] = str(humidity_level(dryer.humidity))
    if dryer.temperature >= 0:
        out["temp"] = "%.1f" % dryer.temperature
    if dryer.drying:
        out["dry_setting"] = {"dry_filament": filament, "dry_temperature": int(round(dryer.target)),
                              "dry_duration": max(1, -(-dryer.duration_s // 3600))}
    return out


def unit_name(shown: Layout, box: Box) -> str:
    """The AFC unit a four-tray unit shows, numbered when it takes more than one."""
    parts = [b for b in shown.boxes if b.unit == box.unit and not b.single]
    return box.unit if len(parts) == 1 else "%s-%d" % (box.unit, parts.index(box) + 1)


def ams_json(snapshot: Snapshot, filament_ids: dict, extras: dict | None = None, reading=(),
             by_unit: bool = False, dry_filaments: dict | None = None, wide: bool = False) -> dict:
    """The "ams" object of a push_status message for AFC's lanes, laid out by
    layout(). `filament_ids` holds the filament id for each loaded T number,
    `extras` more tray fields by T number, `reading` the T numbers whose tag is
    being read, `dry_filaments` the filament each drying unit was started for."""
    trays = lanes_by_tray(snapshot)
    if not trays:
        return {"ams": [], "ams_exist_bits": "0", "tray_exist_bits": "0"}
    extras, dry_filaments = extras or {}, dry_filaments or {}
    shown = layout(snapshot, by_unit, wide)
    limits = shown.limits
    hts = [box for box in shown.boxes if box.single]
    units, ams_bits, tray_bits, reading_bits = [], 0, 0, 0
    for box in shown.boxes:
        unit = snapshot.find_unit(box.unit) if box.unit else None
        dryer = unit.dryer if unit is not None else None
        ams_bits |= 1 << (limits.ht_ams_bit + box.ams_id - HT_ID if box.single else box.ams_id)
        slots = []
        for slot, tool in enumerate(box.tools):
            bit = limits.ht_tray_bit + box.ams_id - HT_ID if box.single else box.ams_id * 4 + slot
            lane = trays.get(tool)
            if lane is not None and lane.has_filament:
                tray_bits |= 1 << bit
            if tool in reading:
                reading_bits |= 1 << bit
            slots.append(tray_json(slot, lane, filament_ids.get(tool, ""), extras.get(tool), tool,
                                   switch_toolheads(snapshot, lane)))
        kind = AMS_HT if box.single else AMS_2_PRO if dryer is not None else AMS
        # OrcaSlicer draws an AMS Lite's four trays in a square, and none at all for fewer.
        if kind == AMS and unit is not None and unit.model == LITE and len(box.tools) == 4:
            kind = AMS_LITE
        # "info": the AMS type, on the first extruder, and its dryer's state.
        info = kind | ((DRYING << 4 | HEATING << 22) if dryer is not None and dryer.drying else 0)
        entry = {"id": str(box.ams_id), "info": "%04X" % info, "tray": slots}
        if box.unit and not box.single:
            entry["unit_name"] = unit_name(shown, box)
        elif unit is not None and unit.type == TOOLCHANGER and trays.get(box.tools[0]) is not None:
            # A toolchanger's tool shows its extruder's name, not "AMS HT".
            tool_lane = trays[box.tools[0]]
            entry["unit_name"] = tool_lane.extruder or tool_lane.name
        elif box.unit:
            # A one-lane unit shows its AFC name, not "AMS HT".
            entry["unit_name"] = box.unit
        elif box.single and box.ams_id != HT_ID + hts.index(box):
            # OrcaSlicer numbers an AMS HT by its id, which starts later beside five four-tray units.
            entry["unit_name"] = "AMS HT-%d" % (hts.index(box) + 1)
        if dryer is not None:
            entry.update(dryer_json(dryer, dry_filaments.get(box.unit, "")))
        elif box.single:
            entry["dryer"] = False
        else:
            entry["humidity"] = "0"  # an AMS shows a humidity level 1-5 (5 when not sent)
        # The filament switch inlet the AFC unit is plumbed into, on each of the units that show it.
        entry.update(unit_switch(snapshot, box.unit))
        units.append(entry)
    now = "%d" % shown.tray(current_tray(snapshot))
    # calibrate_remain_flag: OrcaSlicer draws how full each spool is only while the printer says it tracks it.
    out = {"ams": units, "ams_exist_bits": "%X" % ams_bits, "tray_exist_bits": "%X" % tray_bits,
           "tray_now": now, "tray_tar": now, "tray_reading_bits": "%X" % reading_bits,
           "calibrate_remain_flag": True}
    if limits != BAMBU:
        out.update(ht_ams_bit=limits.ht_ams_bit, ht_tray_bit=limits.ht_tray_bit)
    return out


def _refill_bit(tray: int, limits: Limits = BAMBU):
    """The bit of a tray id in the refill group masks, None past them. Bambu's:
    trays 0-15 and 24-27 at their own bit, AMS HT units at 16-23. The AFC
    build's (WIDE): the tray bits of tray_exist_bits."""
    if limits != BAMBU:
        if 0 <= tray < limits.ht_tray_bit:
            return tray
        if HT_ID <= tray < HT_ID + limits.max_ht:
            return limits.ht_tray_bit + tray - HT_ID
        return None
    if 0 <= tray <= 15 or 24 <= tray <= 27:
        return tray
    if HT_ID <= tray < HT_ID + MAX_HT:
        return 16 + tray - HT_ID
    return None


def refill_groups(snapshot: Snapshot, shown: Layout) -> list:
    """AFC's runout lanes as Bambu's auto refill groups ("filam_bak"): a mask
    of the trays of each set of lanes that run out onto one another, as far as
    the masks reach. The print dialog lists them under "Auto Refill"."""
    lanes = {lane.name: lane for lane in snapshot.lanes}
    parent = {}

    def root(name):
        while parent.get(name, name) != name:
            name = parent[name]
        return name

    linked = set()
    for lane in snapshot.lanes:
        if lane.runout_lane in lanes and lane.runout_lane != lane.name:
            parent[root(lane.name)] = root(lane.runout_lane)
            linked |= {lane.name, lane.runout_lane}
    groups = {}  # root lane -> (tray bits, lanes with a tray)
    for tool, lane in sorted(lanes_by_tray(snapshot).items()):
        bit = _refill_bit(shown.tray(tool), shown.limits) if lane.name in linked else None
        if bit is not None:
            bits, names = groups.setdefault(root(lane.name), (set(), set()))
            bits.add(bit)
            names.add(lane.name)
    return [sum(1 << bit for bit in bits) for bits, names in groups.values() if len(names) > 1]


def lanes_json(snapshot: Snapshot, shown: Layout) -> list:
    """Every AFC lane, for the runout lane choices of the AFC build of
    OrcaSlicer: its unit, filament and material family (material_key()),
    grams (-1 unknown), toolhead, the lane it runs out onto ("" for none), the
    lanes with the same filament (runout.same_filament()) and where the
    Device tab shows it, and its T numbers, Spoolman spool (0 none) and
    temperatures (0 unknown), and whether its unit is connected (a BridgeBox
    or ACE unit whose link is down has no spools to offer). A lane behind a
    filament switch also says its switch and inlet (unit_switch()) and, while
    the switch can move it, the two toolheads it reaches (switch_toolheads())."""
    out = []
    for lane in snapshot.lanes:
        unit = snapshot.find_unit(lane.unit)
        ams_id, slot_id = shown.place(lane)
        same = [other.name for other in snapshot.lanes if other is not lane and runout.same_filament(lane, other)]
        heads = switch_toolheads(snapshot, lane)
        out.append({"name": lane.name, "unit": lane.unit, "color": _color(lane.color), "type": lane.material,
                    "family": material_key(lane.material),
                    "remain_g": int(round(lane.weight)) if lane.has_filament and lane.weight > 0 else -1,
                    "toolhead": lane.extruder_index, "extruder": lane.extruder, "loaded": lane.has_filament,
                    "in_tool": lane.tool_loaded, "runout": lane.runout_lane, "same": same,
                    "ams_id": ams_id, "slot_id": slot_id,
                    # For the suggested spool layout, which writes a moved spool's lane back to AFC.
                    "tools": [tool_number(m) for m in lane.maps if tool_number(m) >= 0],
                    "spool_id": lane.spool_id, "nozzle_temp": lane.nozzle_temp, "bed_temp": lane.bed_temp,
                    "online": unit.online if unit else True,
                    **unit_switch(snapshot, lane.unit), **({"switch_toolheads": heads} if heads else {})})
    return out


def switch_toolheads(snapshot: Snapshot, lane: Lane | None) -> list:
    """The two toolheads the filament switch of a lane can feed it to, outlet
    A's first. Empty for a lane on no switch, and while its switch cannot
    move it: not answering, not calibrated, or an outlet not in use."""
    switch = snapshot.switch_of(lane.name) if lane is not None else None
    if switch is None or not switch.answering or not switch.calibrated:
        return []
    heads = switch.toolheads()
    return heads if len(heads) == 2 and min(heads) >= 0 else []


def unit_switch(snapshot: Snapshot, unit: str) -> dict:
    """{"switch", "switch_inlet"} of an AFC unit plumbed into a filament
    switch: the switch's place in switches_json() and its inlet's letter.
    Empty for a unit on none."""
    inlet = snapshot.switch_inlet(unit)
    return {"switch": inlet[0], "switch_inlet": inlet[1]} if inlet else {}


def switch_text(switch: Switch) -> str:
    """A filament switch in words, a line for each inlet: its units, where it
    exits now and what it holds, then what keeps the switch from working."""
    extruders = {outlet.letter: outlet.extruder for outlet in switch.outlets}
    lines = [switch.name]
    for inlet in switch.inlets:
        where = "outlet %s, %s" % (inlet.outlet, extruders.get(inlet.outlet) or "no extruder") if inlet.outlet else "moving"
        holds = inlet.lane + " loaded" if inlet.lane else "holds filament" if inlet.filament else "empty"
        lines.append("Inlet %s (%s): %s, %s" % (inlet.letter, ", ".join(inlet.units) or "no unit", where, holds))
    if not switch.answering:
        lines.append("The switch is not answering")
    if not switch.calibrated:
        lines.append("Tube lengths not set: run AFC Calibration")
    return "\n".join(lines)


def switches_json(snapshot: Snapshot) -> list:
    """Every filament switch, for the AFC build of OrcaSlicer, which draws it
    between its units and its toolheads: whether it answers and is
    calibrated, each inlet's units, the outlet it exits at now ("" when not
    known), whether it holds filament, and its lane loaded in a toolhead with
    that lane's color ("" for no lane or no color), each outlet's extruder
    ("" for none) and toolhead (-1 for none), and switch_text() for its tooltip."""
    out = []
    for switch in snapshot.switches:
        inlets = []
        for inlet in switch.inlets:
            lane = snapshot.find_lane(inlet.lane) if inlet.lane else None
            inlets.append({"letter": inlet.letter, "outlet": inlet.outlet, "filament": inlet.filament,
                           "lane": inlet.lane, "color": _color(lane.color) if lane is not None else "",
                           "units": list(inlet.units)})
        outlets = [{"letter": outlet.letter, "extruder": outlet.extruder, "toolhead": toolhead}
                   for outlet, toolhead in zip(switch.outlets, switch.toolheads())]
        out.append({"name": switch.name, "answering": switch.answering, "calibrated": switch.calibrated,
                    "inlets": inlets, "outlets": outlets, "text": switch_text(switch)})
    return out


def mapping_from_print(ams_mapping: str, ams_mapping2: str, filaments: int, shown: Layout | None = None) -> dict:
    """The print dialog's choice as file filament -> AFC T number. The
    dialog sends one entry per project filament: a tray id in ams_mapping,
    and {ams_id, slot_id} in ams_mapping2 (0xFF for none). `shown` is the
    layout the dialog picked from (by T number when not given)."""
    shown = shown or Layout([])
    out = {}
    try:
        first = json.loads(ams_mapping or "[]")
    except ValueError:
        first = []
    try:
        second = json.loads(ams_mapping2 or "[]")
    except ValueError:
        second = []
    for filament in range(filaments):
        tool = -1
        if isinstance(first, list) and filament < len(first):
            tool = shown.tool_of_tray(first[filament])
        if tool < 0 and isinstance(second, list) and filament < len(second):
            item = second[filament]
            if isinstance(item, dict):
                tool = shown.tool(item.get("ams_id"), item.get("slot_id"))
        if tool >= 0:
            out[filament] = tool
    return out


# A color this close (RGB distance, 0-441) counts as the same color.
SAME_COLOR = 60.0


def _rgb(color: str):
    text = (color or "").lstrip("#")
    if len(text) not in (6, 8):
        return None
    try:
        return tuple(int(text[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return None


def color_distance(a: str, b: str) -> float:
    """How far apart two "#RRGGBB[AA]" colors are, 999 when one is unknown."""
    first, second = _rgb(a), _rgb(b)
    if first is None or second is None:
        return 999.0
    return sum((x - y) ** 2 for x, y in zip(first, second)) ** 0.5


def auto_mapping(snapshot: Snapshot, filaments: list, types: list, colors: list, toolheads: list) -> dict:
    """File filament -> AFC T number for a print the Multi-device tab sends to
    several printers at once, which picks no trays for any one printer. Each
    filament the file prints (`filaments`) goes to a loaded lane of the same
    material (`types`), else of the same material family (PLA for PLA-CF), of
    the same color (`colors`) first, then on the toolhead it was sliced for
    (`toolheads`), then of the closest color, then its own T number; a lane
    takes a second filament only when no other matches. A filament no lane
    matches keeps its own T number."""
    lanes = [(lane, tool_number(lane.maps[0])) for lane in snapshot.lanes
             if lane.has_filament and lane.maps and tool_number(lane.maps[0]) >= 0]
    taken, out = set(), {}
    for filament in filaments:
        kind = (types[filament] if filament < len(types) else "") or ""
        color = colors[filament] if filament < len(colors) else ""
        head = toolheads[filament] if filament < len(toolheads) else -1
        candidates = [pair for pair in lanes if (pair[0].material or "").strip().upper() == kind.strip().upper()]
        if not candidates:
            candidates = [pair for pair in lanes if material_key(pair[0].material) == material_key(kind)]
        if not kind or not candidates:
            continue

        def rank(pair):
            lane, tool = pair
            distance = color_distance(lane.color, color)
            return (tool in taken, distance > SAME_COLOR, head >= 0 and lane.extruder_index != head, distance,
                    tool != filament)

        _, tool = min(candidates, key=rank)
        out[filament] = tool
        taken.add(tool)
    return out
