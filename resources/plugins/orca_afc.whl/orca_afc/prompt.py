"""Klipper's action prompts, which AFC asks its calibration with, for the AFC
build of OrcaSlicer to show as Mainsail and Fluidd do.

A macro opens a prompt by writing lines to the console: `// action:prompt_begin
<title>`, then `prompt_text`, `prompt_button <label>|<gcode>|<style>` (in rows
between `prompt_button_group_start` and `_end`), `prompt_footer_button`, and
`prompt_show`; `prompt_end` closes it. The agent reads them from Moonraker's
G-code store, with the errors (`!! ` lines) printed while OrcaSlicer's G-code
runs, so the window can say how a calibration ended when AFC shows no prompt."""

from __future__ import annotations

import re
import threading

PREFIX = "// action:prompt_"
LINES = 100   # newest G-code store lines read at a time
WATCH = 600.0  # seconds the store is read after OrcaSlicer sends G-code, for the prompts it opens
ERROR = "!! "  # Klipper's and AFC's errors in the console
ERRORS = 5     # errors kept for the window
NOTE = "// "   # Klipper's answers in the console, kept as notes when the G-code asks for them (Watch.start())
LOG = 4        # console lines kept for the window while the G-code runs
LOG_WIDTH = 200
_MARKUP = re.compile(r"<[^>]*>")


def _log_line(line: str) -> str:
    """A console line as the window shows it while the G-code runs: without
    Klipper's "// " and the HTML Mainsail and Fluidd color it with."""
    if line.startswith(NOTE):
        line = line[len(NOTE):]
    line = " ".join(_MARKUP.sub("", line).split())
    return "" if line.lower() == "ok" else line[:LOG_WIDTH]


def _button(rest: str) -> dict:
    """"Lane 1|CALIBRATE_AFC LANE=lane1|primary" -> its label, G-code and style;
    the G-code is the label when the line names none, as in Mainsail."""
    parts = rest.split("|")
    label = parts[0].strip()
    gcode = parts[1].strip() if len(parts) > 1 and parts[1].strip() else label
    style = parts[2].strip() if len(parts) > 2 else ""
    return {"label": label, "gcode": gcode, "style": style}


class Watch:
    """The prompt the console's lines leave open. `id` changes each time one
    opens or closes, an error shows or OrcaSlicer's G-code ends, so OrcaSlicer
    tells a new state from one it already showed."""

    def __init__(self):
        self.seen = None      # time of the newest line read, None before the first read
        self.prompt = None    # the open prompt: {title, text, rows, footer}
        self.id = 0
        self.running = 0      # OrcaSlicer's G-code lines still running
        self.errors = []      # errors printed since the first of them started
        self.notes = []       # answers starting with the G-code's note prefix, printed since it started
        self.log = []         # the newest console lines printed since it started, while it runs
        self._note = ""       # that prefix ("AFC_autocal: "), "" to keep none
        self._since = None    # store time errors are kept after, None until the G-code starts
        self._finished = 0    # G-code lines ended so far
        self._read = 0        # of those, how many ended before a store read that was fed began
        self._building = None
        self._group = None
        self._lock = threading.Lock()

    def start(self, note: str = "") -> None:
        """OrcaSlicer sent G-code, which runs once the G-code before it ends.
        Klipper's answers that start with `note` are kept for the window, as
        the result of a command that reports one that way."""
        with self._lock:
            if self.running == 0:
                self.errors = []
                self.notes = []
                self.log = []
                self._note = ""
                self._since = None
            self._note = note or self._note
            self.running += 1

    def mark(self, newest) -> None:
        """The G-code starts now; `newest` is the time of the store's newest line
        (the printer's clock), None when it could not be read. Errors after it
        are kept until G-code is next sent with none running."""
        with self._lock:
            if self._since is None:
                since = newest if isinstance(newest, (int, float)) else self.seen
                self._since = since if since is not None else float("inf")

    def finish(self) -> None:
        """OrcaSlicer's G-code ended, whether it worked or failed."""
        with self._lock:
            self.running = max(0, self.running - 1)
            self._finished += 1
            self.id += 1

    def busy(self) -> bool:
        """A prompt is open or OrcaSlicer's G-code has not been seen to end: keep reading."""
        with self._lock:
            return self.prompt is not None or self.running > 0 or self._read < self._finished

    def token(self) -> int:
        """Taken before reading the store and handed to feed(): the G-code is
        reported running until a read begun after it ended is fed, so the prompt
        it printed is never missed."""
        with self._lock:
            return self._finished

    def feed(self, entries, token=None) -> bool:
        """Reads the G-code store's entries (oldest first) newer than the last
        read, which began at `token` (token()); True when a prompt opened or closed
        or the running G-code printed a line."""
        with self._lock:
            settled = self._read < self._finished
            self._read = max(self._read, self._finished if token is None else token)
            changed = self._feed(entries)
            if settled and self._read >= self._finished and self.running == 0:
                self.id += 1
                changed = True
            return changed

    def _feed(self, entries) -> bool:
        changed = False
        newest = self.seen
        for entry in entries or ():
            if not isinstance(entry, dict):
                continue
            when = entry.get("time")
            when = when if isinstance(when, (int, float)) else 0.0
            if self.seen is not None and when <= self.seen:
                continue
            newest = when if newest is None else max(newest, when)
            message = entry.get("message")
            for line in (message.splitlines() if isinstance(message, str) else ()):
                changed |= self._line(line.strip(), when)
        self.seen = newest if newest is not None else (self.seen or 0.0)
        return changed

    def _line(self, line: str, when: float) -> bool:
        logged = False
        # Errors are kept apart (below), so the window shows each once.
        if not line.startswith((PREFIX, ERROR)) and self._logging(when):
            text = _log_line(line)
            if text:
                self.log = (self.log + [text])[-LOG:]
                if self.prompt is None:
                    self.id += 1  # the window shows the printer's progress
                    logged = True
        return self._prompt_line(line, when) or logged

    def _prompt_line(self, line: str, when: float) -> bool:
        if line.startswith(ERROR):
            if self._since is None or when <= self._since:
                return False
            self.errors = (self.errors + [line[len(ERROR):].strip()])[-ERRORS:]
            self.id += 1
            return True
        if self._note and line.startswith(NOTE + self._note):
            if self._since is not None and when > self._since:
                self.notes = (self.notes + [line[len(NOTE):].strip()])[-ERRORS:]
            return False
        if not line.startswith(PREFIX):
            return False
        word, _, rest = line[len(PREFIX):].partition(" ")
        building = self._building
        if word == "begin":
            self._building = {"title": rest.strip(), "text": [], "rows": [], "footer": []}
            self._group = None
        elif word == "end":
            self._building = self._group = None
            if self.prompt is not None:
                self.prompt = None
                self.id += 1
                return True
        elif building is None:
            return False
        elif word == "text":
            building["text"].append(rest.strip())
        elif word == "button":
            if self._group is not None:
                self._group.append(_button(rest))
            else:
                building["rows"].append([_button(rest)])
        elif word == "button_group_start":
            self._group = []
        elif word == "button_group_end":
            if self._group:
                building["rows"].append(self._group)
            self._group = None
        elif word == "footer_button":
            building["footer"].append(_button(rest))
        elif word == "show":
            self.prompt = building
            self.id += 1
            return True
        return False

    def _logging(self, when: float) -> bool:
        """A line printed after OrcaSlicer's G-code started, while it still runs."""
        return self._since is not None and when > self._since and (self.running > 0 or self._read < self._finished)

    def json(self) -> dict:
        """The agent_prompt the AFC build of OrcaSlicer shows: {id, open, running,
        errors, notes, log} and the open prompt's title, text lines, rows of buttons
        and footer buttons."""
        out = {"id": self.id, "open": self.prompt is not None,
               "running": self.running > 0 or self._read < self._finished,
               "errors": list(self.errors), "notes": list(self.notes), "log": list(self.log)}
        if self.prompt is not None:
            out.update(self.prompt)
        return out
